/*
INPUT:
- <degree1>: Degree of the first polynomial
- <coeff1_0>, <coeff1_1>, ..., <coeff1_degree1>: Coefficients of the first polynomial (starting from the constant term)
- <degree2>: Degree of the second polynomial
- <coeff2_0>, <coeff2_1>, ..., <coeff2_degree2>: Coefficients of the second polynomial (starting from the constant term)

The input should be provided in the following format:
- First argument: degree of the first polynomial
- Next <degree1 + 1> arguments: coefficients of the first polynomial
- Next argument: degree of the second polynomial
- Next <degree2 + 1> arguments: coefficients of the second polynomial

Example Input:
./polynomialMultiply.exe 2 1 2 3 1 4 5
This represents:
First polynomial: 1 + 2x + 3x^2
Second polynomial: 4 + 5x
*/


#include <iostream>
#include <vector>
#include <complex>
#include <cmath>

using namespace std;

typedef complex<double> Complex;
const double PI = acos(-1);

void fft(vector<Complex>& x) {
    int N = x.size();
    if (N <= 1) return;

    vector<Complex> even(N / 2), odd(N / 2);
    for (int i = 0; i < N / 2; i++) {
        even[i] = x[i * 2];
        odd[i] = x[i * 2 + 1];
    }

    fft(even);
    fft(odd);

    for (int k = 0; k < N / 2; k++) {
        Complex t = polar(1.0, -2 * PI * k / N) * odd[k];
        x[k] = even[k] + t;
        x[k + N / 2] = even[k] - t;
    }
}

vector<Complex> multiplyPolynomials(const vector<double>& a, const vector<double>& b) {
    int n = a.size() + b.size() - 1;
    int m = 1;
    while (m < n) m *= 2;

    vector<Complex> fa(m), fb(m);
    for (size_t i = 0; i < a.size(); i++) fa[i] = a[i];
    for (size_t i = 0; i < b.size(); i++) fb[i] = b[i];

    fft(fa);
    fft(fb);

    vector<Complex> result(m);
    for (int i = 0; i < m; i++) {
        result[i] = fa[i] * fb[i];
        result[i] = round(result[i].real());
    }

    return result;
}

int main(int argc, char* argv[]) {
    if (argc < 5) {
        cout << "Usage: " << argv[0] << " <degree1> <coeff1_0> ... <coeff1_degree1> <degree2> <coeff2_0> ... <coeff2_degree2>" << endl;
        return 1;
    }

    // Parse the first polynomial
    int index = 1;
    int degree1 = atoi(argv[index++]);
    vector<double> poly1(degree1 + 1);
    for (int i = 0; i <= degree1; i++) {
        poly1[i] = atof(argv[index++]);
    }

    // Parse the second polynomial
    int degree2 = atoi(argv[index++]);
    vector<double> poly2(degree2 + 1);
    for (int i = 0; i <= degree2; i++) {
        poly2[i] = atof(argv[index++]);
    }

    vector<Complex> result = multiplyPolynomials(poly1, poly2);

    cout << "Resultant polynomial coefficients: " << endl;
    for (const auto& coeff : result) {
        cout << coeff.real() << " ";
    }
    cout << endl;

    return 0;
}

