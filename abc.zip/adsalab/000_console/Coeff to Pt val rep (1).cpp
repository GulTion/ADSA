#include <iostream>
#include <vector>
#include <complex>
#include <cmath>

using namespace std;

typedef complex<double> Complex;
const double PI = acos(-1);

void fft(vector<Complex>& x) {
    int N = x.size();
    if (N <= 1) return;

    vector<Complex> even(N / 2), odd(N / 2);
    for (int i = 0; i < N / 2; i++) {
        even[i] = x[i * 2];
        odd[i] = x[i * 2 + 1];
    }

    fft(even);
    fft(odd);

    for (int k = 0; k < N / 2; k++) {
        Complex t = polar(1.0, -2 * PI * k / N) * odd[k];
        x[k] = even[k] + t;
        x[k + N / 2] = even[k] - t;
    }
}

vector<Complex> multiplyPolynomials(const vector<Complex>& a, const vector<Complex>& b) {
    int n = a.size() + b.size() - 1;
    int m = 1;
    while (m < n) m *= 2;

    vector<Complex> fa(m), fb(m);
    for (size_t i = 0; i < a.size(); i++) fa[i] = a[i];
    for (size_t i = 0; i < b.size(); i++) fb[i] = b[i];

    fft(fa);
    fft(fb);

    vector<Complex> result(m);
    for (int i = 0; i < m; i++) {
        result[i] = fa[i] * fb[i];
    }

    fft(result);
    for (auto& x : result) x /= m;

    return result;
}

int main() {
    int degree1, degree2;

    // Input for the first polynomial
    cout << "Enter the degree of the first polynomial: ";
    cin >> degree1;
    vector<Complex> poly1(degree1 + 1);
    cout << "Enter the real coefficients of the first polynomial (from lowest degree to highest):" << endl;
    for (int i = 0; i <= degree1; i++) {
        double real;
        cin >> real;
        poly1[i] = Complex(real, 0); // Imaginary part is zero
    }

    // Input for the second polynomial
    cout << "Enter the degree of the second polynomial: ";
    cin >> degree2;
    vector<Complex> poly2(degree2 + 1);
    cout << "Enter the real coefficients of the second polynomial (from lowest degree to highest):" << endl;
    for (int i = 0; i <= degree2; i++) {
        double real;
        cin >> real;
        poly2[i] = Complex(real, 0); // Imaginary part is zero
    }

    // Perform polynomial multiplication
    vector<Complex> result = multiplyPolynomials(poly1, poly2);

    // Output the resultant polynomial
    cout << "Resultant polynomial coefficients (real parts): " << endl;
    for (const auto& coeff : result) {
        cout << coeff.real() << " ";
    }
    cout << endl;

    return 0;
}

