#include <iostream>
#include <fstream>
#include <cstring>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 1024

void send_file(int sock, const std::string& filepath) {
    char buffer[BUFFER_SIZE] = {0};

    // Extract file name from file path
    std::string filename = filepath.substr(filepath.find_last_of("/") + 1);

    // Send the file name to the server
    send(sock, filename.c_str(), filename.size(), 0);

    // Open the file for reading
    std::ifstream infile(filepath, std::ios::binary);
    if (!infile) {
        std::cerr << "Failed to open file: " << filepath << "\n";
        return;
    }

    std::cout << "Sending file: " << filename << "\n";

    // Send file content
    while (!infile.eof()) {
        infile.read(buffer, BUFFER_SIZE);
        int bytes_read = infile.gcount();
        send(sock, buffer, bytes_read, 0);
    }

    infile.close();
    std::cout << "File sent successfully.\n";
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cerr << "Usage: " << argv[0] << " <file_path>\n";
        return -1;
    }

    std::string filepath = argv[1];
    int sock = 0;
    struct sockaddr_in serv_addr;

    // Create socket
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        std::cerr << "Socket creation error\n";
        return -1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);

    // Convert IPv4 address from text to binary
    if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) {
        std::cerr << "Invalid address/Address not supported\n";
        return -1;
    }

    // Connect to the server
    if (connect(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        std::cerr << "Connection failed\n";
        return -1;
    }

    std::cout << "Connected to the server.\n";

    // Send file to the server
    send_file(sock, filepath);

    close(sock);
    return 0;
}
