/*
INPUT:
- The input format consists of multiple arguments:
    1. <degree1>: The degree of the first polynomial.
    2. <coeff1> <coeff2> ...: The coefficients of the first polynomial (real numbers).
    3. <degree2>: The degree of the second polynomial.
    4. <coeff1> <coeff2> ...: The coefficients of the second polynomial (real numbers).

Example Input:
./fft_polynomial.exe 2 1 3 5 2 2 4 5
This represents:
- The first polynomial: P1(x) = 1 + 3x + 5x� (degree 2)
- The second polynomial: P2(x) = 2 + 4x + 5x� (degree 2)
*/

#include <iostream>
#include <vector>
#include <complex>
#include <cmath>
#include <string>
#include <sstream>

using namespace std;

typedef complex<double> Complex;
const double PI = acos(-1);

void fft(vector<Complex>& x) {
    int N = x.size();
    if (N <= 1) return;

    vector<Complex> even(N / 2), odd(N / 2);
    for (int i = 0; i < N / 2; i++) {
        even[i] = x[i * 2];
        odd[i] = x[i * 2 + 1];
    }

    fft(even);
    fft(odd);

    for (int k = 0; k < N / 2; k++) {
        Complex t = polar(1.0, -2 * PI * k / N) * odd[k];
        x[k] = even[k] + t;
        x[k + N / 2] = even[k] - t;
    }
}

vector<Complex> multiplyPolynomials(const vector<Complex>& a, const vector<Complex>& b) {
    int n = a.size() + b.size() - 1;
    int m = 1;
    while (m < n) m *= 2;

    vector<Complex> fa(m), fb(m);
    for (size_t i = 0; i < a.size(); i++) fa[i] = a[i];
    for (size_t i = 0; i < b.size(); i++) fb[i] = b[i];

    fft(fa);
    fft(fb);

    vector<Complex> result(m);
    for (int i = 0; i < m; i++) {
        result[i] = fa[i] * fb[i];
    }

    fft(result);  // Apply inverse FFT to get the time-domain result
    for (auto& x : result) x /= m;  // Scale back after inverse FFT

    return result;
}

// Helper function to parse complex numbers from string input
Complex parseComplex(const string& s) {
    double real = 0.0, imag = 0.0;
    char op = '+';
    size_t pos = s.find_first_of("+-", 1);

    if (pos != string::npos) {
        real = stod(s.substr(0, pos));
        op = s[pos];
        imag = stod(s.substr(pos + 1, s.size() - pos - 2));  // Strip the trailing 'j'
        if (op == '-') imag = -imag;
    } else {
        real = stod(s);  // if only real part
    }
    
    return Complex(real, imag);
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        cout << "Usage: " << argv[0] << " <degree1> <coeff1> <coeff2> ... <degree2> <coeff1> <coeff2> ..." << endl;
        return 1;
    }

    int argIndex = 1;

    // Parse first polynomial
    int degree1 = stoi(argv[argIndex++]);
    vector<Complex> poly1(degree1 + 1);
    for (int i = 0; i <= degree1; i++) {
        poly1[i] = parseComplex(argv[argIndex++]);
    }

    // Parse second polynomial
    int degree2 = stoi(argv[argIndex++]);
    vector<Complex> poly2(degree2 + 1);
    for (int i = 0; i <= degree2; i++) {
        poly2[i] = parseComplex(argv[argIndex++]);
    }

    // Perform polynomial multiplication
    vector<Complex> result = multiplyPolynomials(poly1, poly2);

    // Output the resultant polynomial
    cout << "Resultant polynomial coefficients:" << endl;
    for (const auto& coeff : result) {
        cout << coeff << " ";
    }
    cout << endl;

    return 0;
}

