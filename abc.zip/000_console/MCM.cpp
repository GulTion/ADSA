#include <iostream>
#include <climits>
#include <sstream>

using namespace std;

// Function to compute matrix chain order
void matrixChainOrder(int* dims, int n, int** m, int** s) {
    for (int i = 1; i < n; i++)
        m[i][i] = 0; // No cost to multiply one matrix
    
    for (int L = 2; L < n; L++) { // L is chain length
        for (int i = 1; i <= n - L; i++) {
            int j = i + L - 1;
            m[i][j] = INT_MAX;
            for (int k = i; k < j; k++) {
                int q = m[i][k] + m[k + 1][j] + dims[i - 1] * dims[k] * dims[j];
                if (q < m[i][j]) {
                    m[i][j] = q;
                    s[i][j] = k; // Record the split point
                }
            }
        }
    }
}

// Function to print optimal parenthesization
void printOptimalParens(int** s, int i, int j) {
    if (i == j) {
        cout << "A" << i;
    } else {
        cout << "(";
        printOptimalParens(s, i, s[i][j]);
        printOptimalParens(s, s[i][j] + 1, j);
        cout << ")";
    }
}

// Function to print m and s tables with proper labels
void printTable(int** table, int n, const string& name, bool isSplitTable = false) {
    cout << name << " Table:" << endl;
    for (int i = 1; i < n; i++) {
        for (int j = 1; j < n; j++) {
            if (i <= j) {
                if (isSplitTable && i == j) {
                    cout << "-\t"; // Print '-' in diagonal for s table
                } else {
                    cout << table[i][j] << "\t";
                }
            } else {
                cout << "-\t"; // Print '-' for unused cells
            }
        }
        cout << endl;
    }
    cout << endl;
}

int main() {
    string input;
    cout << "Enter matrix dimensions ";
    getline(cin, input);

    // Parse comma-separated values
    int dims[100], n = 0;
    stringstream ss(input);
    while (ss.good()) {
        string value;
        getline(ss, value, ' ');
        dims[n++] = stoi(value);
    }

    // Define m and s tables dynamically
    int** m = new int*[n];
    int** s = new int*[n];
    for (int i = 0; i < n; i++) {
        m[i] = new int[n];
        s[i] = new int[n];
    }

    // Compute matrix chain order
    matrixChainOrder(dims, n, m, s);

    // Output the minimum cost
    cout << "Minimum number of multiplications is: " << m[1][n - 1] << endl;

    // Output the m and s tables
    printTable(m, n, "m");
    printTable(s, n, "s", true); // true flag to mark s as split table

    // Output the optimal parenthesization
    cout << "Optimal parenthesization: ";
    printOptimalParens(s, 1, n - 1);
    cout << endl;

    // Deallocate memory
    for (int i = 0; i < n; i++) {
        delete[] m[i];
        delete[] s[i];
    }
    delete[] m;
    delete[] s;

    return 0;
}
