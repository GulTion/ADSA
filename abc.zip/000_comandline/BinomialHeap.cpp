/*
INPUT
comma seperated 'n' nodes
*/

#include <bits/stdc++.h>

typedef struct Node {
    int val;
    int rank;
    struct Node* parent;
    struct Node* child;
    struct Node* next;
} Node;

Node* createNode(int val) {
    Node* node = (Node*)malloc(sizeof(Node));
    node->val = val;
    node->rank = 0;
    node->parent = node->child = node->next = NULL;
    return node;
}

typedef struct Heap {
    Node* head;
} Heap;

Node* combineTrees(Node* a, Node* b) {
    if (a->val > b->val) {
        Node* temp = a;
        a = b;
        b = temp;
    }
    b->parent = a;
    b->next = a->child;
    a->child = b;
    a->rank++;
    return a;
}

Heap* mergeHeaps(Heap* h1, Heap* h2) {
    Heap* merged = (Heap*)malloc(sizeof(Heap));
    merged->head = NULL;

    Node* prev = NULL;
    Node* cur = h1->head;
    Node* nxt = h2->head;

    while (cur || nxt) {
        Node* minNode;
        if (!nxt || (cur && cur->rank <= nxt->rank)) {
            minNode = cur;
            cur = cur->next;
        } else {
            minNode = nxt;
            nxt = nxt->next;
        }

        if (merged->head == NULL) {
            merged->head = minNode;
            prev = merged->head;
        } else {
            prev->next = minNode;
            prev = prev->next;
        }
    }

    Node* curr = merged->head;
    Node* last = NULL;
    Node* nxtNode = curr ? curr->next : NULL;

    while (nxtNode) {
        if ((curr->rank != nxtNode->rank) || 
            (nxtNode->next && nxtNode->next->rank == curr->rank)) {
            last = curr;
            curr = nxtNode;
        } else {
            if (curr->val <= nxtNode->val) {
                curr->next = nxtNode->next;
                curr = combineTrees(curr, nxtNode);
            } else {
                if (last) {
                    last->next = nxtNode;
                } else {
                    merged->head = nxtNode;
                }
                nxtNode = combineTrees(nxtNode, curr);
                curr = nxtNode;
            }
        }
        nxtNode = curr->next;
    }

    return merged;
}

void add(Heap** heap, int val) {
    Heap* tempHeap = (Heap*)malloc(sizeof(Heap));
    tempHeap->head = createNode(val);
    *heap = mergeHeaps(*heap, tempHeap);
}

void gatherEdges(Node* root) {
    Node* child = root->child;
    int isFirst = 1;

    while (child) {
        if (!isFirst) printf(",");
        printf("(%d,%d)", root->val, child->val);
        gatherEdges(child);
        child = child->next;
        isFirst = 0;
    }
}

void printTree(Node* root) {
    printf("B%d,%d,[", root->rank, root->val);
    if (root->child) {
        gatherEdges(root);
    }
    printf("]\n");
}

void printHeap(Heap* heap) {
    Node* root = heap->head;
    while (root) {
        printTree(root);
        root = root->next;
    }
}

char* getToken(const char* str, const char* delim, int index) {
    char* strCopy = strdup(str);
    char* token = strtok(strCopy, delim);
    while (token && index--) token = strtok(NULL, delim);
    char* result = token ? strdup(token) : NULL;
    free(strCopy);
    return result;
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s <comma-separated values>\n", argv[0]);
        return 1;
    }

    Heap* heap = (Heap*)malloc(sizeof(Heap));
    heap->head = NULL;

    const char* input = argv[1];
    const char* delim = ",";
    int index = 0;
    char* token;

    while ((token = getToken(input, delim, index)) != NULL) {
        int val = atoi(token);
        add(&heap, val);
        free(token);
        index++;
    }

    printHeap(heap);
    return 0;
}
