/*
INPUT:
- V: Number of vertices in the graph
- E: Number of edges in the graph
- u1, v1, weight1: Starting vertex, ending vertex, and weight of the first edge
- u2, v2, weight2: Starting vertex, ending vertex, and weight of the second edge
- ...
- uE, vE, weightE: Starting vertex, ending vertex, and weight of the E-th edge

The command line arguments should be provided in the following format:
- First argument: number of vertices (V)
- Second argument: number of edges (E)
- Next 3*E arguments: Each set of three values representing an edge with starting vertex (u), ending vertex (v), and weight

Example Input (for V = 4 and E = 5):
./BellmanFORD.exe 4 5 0 1 1 1 2 -1 2 0 -1 1 3 2 3 0 1
./BellmanFORD.exe 5 6 0 1 10 0 2 5 1 2 2 1 3 1 2 4 3 3 1 4 4 0 3
*/


#include <iostream>
#include <vector>
#include <climits>
#include <cstdlib>

using namespace std;

// Structure to represent an edge
struct Edge {
    int u, v, weight;
};

// Structure to represent a graph
struct Graph {
    int V, E;
    vector<Edge> edges;

    // Constructor to initialize a graph
    Graph(int V, int E) : V(V), E(E), edges(E) {}
};

// Function to add an edge to the graph
void addEdge(Graph& graph, int index, int u, int v, int weight) {
    graph.edges[index].u = u;
    graph.edges[index].v = v;
    graph.edges[index].weight = weight;
}

// Function to run the Bellman-Ford algorithm
void bellmanFord(const Graph& graph, int src) {
    int V = graph.V;
    int E = graph.E;
    vector<int> dist(V, INT_MAX);

    // Distance to the source is always 0
    dist[src] = 0;

    // Relax all edges V-1 times
    for (int i = 1; i <= V - 1; i++) {
        for (int j = 0; j < E; j++) {
            int u = graph.edges[j].u;
            int v = graph.edges[j].v;
            int weight = graph.edges[j].weight;
            if (dist[u] != INT_MAX && dist[u] + weight < dist[v]) {
                dist[v] = dist[u] + weight;
            }
        }
    }

    // Check for negative weight cycles
    for (int i = 0; i < E; i++) {
        int u = graph.edges[i].u;
        int v = graph.edges[i].v;
        int weight = graph.edges[i].weight;
        if (dist[u] != INT_MAX && dist[u] + weight < dist[v]) {
            cout << "Graph contains a negative weight cycle\n";
            return;
        }
    }

    // Print the result
    cout << "Vertex, Distance from Source\n";
    for (int i = 0; i < V; i++) {
        if (dist[i] == INT_MAX) {
            cout << i << ", INF\n";
        } else {
            cout << i << ", " << dist[i] << "\n";
        }
    }
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        cout << "Usage: " << argv[0] << " <V> <E> <u1> <v1> <weight1> ... <uE> <vE> <weightE>\n";
        return 1;
    }

    int V = atoi(argv[1]);
    int E = atoi(argv[2]);

    if (V <= 0 || E < 0) {
        cout << "Invalid number of vertices or edges.\n";
        return 1;
    }

    Graph graph(V, E);

    int argIndex = 3;
    for (int i = 0; i < E; i++) {
        if (argIndex + 2 >= argc) {
            cout << "Insufficient number of arguments for edges.\n";
            return 1;
        }

        int u = atoi(argv[argIndex]);
        int v = atoi(argv[argIndex + 1]);
        int weight = atoi(argv[argIndex + 2]);

        if (u < 0 || u >= V || v < 0 || v >= V) {
            cout << "Invalid edge vertices. They must be between 0 and " << V - 1 << ".\n";
            return 1;
        }

        addEdge(graph, i, u, v, weight);
        argIndex += 3;
    }

    cout << "Running Bellman-Ford algorithm from source vertex 0\n";
    bellmanFord(graph, 0);

    return 0;
}
