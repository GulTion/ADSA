#include <bits/stdc++.h>
using namespace std;

// Function to build the prefix table (LPS array)
vector<int> prefixTable(string p) {
    int m = p.length();
    vector<int> F(m);
    
    int i = 1;
    int j = 0;
    
    while (i < m) {
        if (p[i] == p[j]) {
            F[i] = j + 1;
            i++;
            j++;
        } else if (j > 0) {
            j = F[j - 1];
        } else {
            F[i] = 0;
            i++;
        }
    }

    // Print the prefix function in tabular form
    cout << "Prefix Function (Table):" << endl;
    cout << setw(10) << "Index" << "\t";
    for (int i = 0; i < m; i++) {
        cout << i << "\t";
    }
    cout << endl;

    cout << setw(10) << "Pattern" << "\t";
    for (int i = 0; i < m; i++) {
        cout << p[i] << "\t";
    }
    cout << endl;

    cout << setw(10) << "Prefix" << "\t";
    for (int i = 0; i < m; i++) {
        cout << F[i] << "\t";
    }
    cout << "\n\n";
    
    return F;
}

// Modified KMP Matcher to output all matching indices
vector<int> kmpMatcher(string p, string t) {
    int n = t.length();
    int m = p.length();
    vector<int> F = prefixTable(p);
    vector<int> result;  // Vector to store the starting indices of matches
    
    int i = 0;
    int j = 0;
    
    while (i < n) {
        if (p[j] == t[i]) {
            if (j == m - 1) {
                result.push_back(i - m + 1);  // Store the index of the match
                j = F[j];  // Continue searching for next matches
                i++;
            } else {
                i++;
                j++;
            }
        } else {
            if (j > 0) {
                j = F[j - 1];
            } else {
                i++;
            }
        }
    }

    return result;
}

int main() {
    string text, pattern;

    // Take user input for text and pattern
    cout << "Enter the text: ";
    getline(cin, text);
    
    cout << "Enter the pattern: ";
    getline(cin, pattern);
    
    if (pattern.length() > text.length()) {
        vector<int> matches = kmpMatcher(pattern, text);
        cout << "Pattern is longer than text. Not matched!" << endl;
    } else {
        vector<int> matches = kmpMatcher(pattern, text);
        
        if (matches.size() > 0) {
            cout << "Pattern found at indices (0-based): " << endl;
            for (int idx : matches) {
                cout << "=> " << idx << "\n";
            }
            cout << endl;  
        } else {
            cout << "Pattern does not exist in the text." << endl;
        }
    }

    return 0;
}

