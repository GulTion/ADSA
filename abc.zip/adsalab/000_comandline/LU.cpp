/*
 * INPUT FORMAT:
 *
 * The program expects the following command-line arguments:
 * 1. <size> (required) - The size of the square matrix (n x n).
 *    Example: 3
 *
 * 2. <matrix elements> (required) - The n x n elements of the matrix, 
 *    provided as space-separated values in row-major order. The total 
 *    number of elements should be exactly n * n.
 *    Example: 1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0
 *
 * The program will perform LU decomposition on the input matrix A and output
 * the resulting lower triangular matrix (L) and upper triangular matrix (U).
 * 
 * Example command to run the program:
 * $ ./luDecomposition 3 1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0
 *
 * Output:
 * Lower Triangular Matrix (L):
 * 1 0 0 
 * 4 1 0 
 * 7 2 1 
 *
 * Upper Triangular Matrix (U):
 * 1 2 3 
 * 0 1 2 
 * 0 0 3 
 *
 * Notes:
 * - The matrix elements are expected to be floating-point numbers.
 * - The matrix must be square (i.e., the number of rows and columns must be equal).
 * - The program assumes that the matrix is invertible (i.e., the LU decomposition exists).
 * - Ensure that the correct number of elements are provided. The program expects exactly n * n elements.
 */


#include <iostream>
#include <vector>
#include <stdexcept>
#include <sstream>

void luDecomposition(const std::vector<std::vector<double>>& A, std::vector<std::vector<double>>& L, std::vector<std::vector<double>>& U) {
    int n = A.size();
    L = std::vector<std::vector<double>>(n, std::vector<double>(n, 0));
    U = std::vector<std::vector<double>>(n, std::vector<double>(n, 0));

    for (int i = 0; i < n; ++i) {
        for (int j = i; j < n; ++j) {
            U[i][j] = A[i][j];
            for (int k = 0; k < i; ++k) {
                U[i][j] -= L[i][k] * U[k][j];
            }
        }
        for (int j = i + 1; j < n; ++j) {
            L[j][i] = A[j][i];
            for (int k = 0; k < i; ++k) {
                L[j][i] -= L[j][k] * U[k][i];
            }
            L[j][i] /= U[i][i];
        }
        L[i][i] = 1.0;
    }
}

std::vector<std::vector<double>> parseMatrixFromArgs(int n, char* argv[]) {
    std::vector<std::vector<double>> A(n, std::vector<double>(n));
    int argIndex = 2;

    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            A[i][j] = std::stod(argv[argIndex++]);
        }
    }

    return A;
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        std::cerr << "Usage: " << argv[0] << " <size> <matrix elements...>" << std::endl;
        return 1;
    }

    int n = std::stoi(argv[1]);
    if (n <= 0) {
        std::cerr << "Matrix size must be positive." << std::endl;
        return 1;
    }
    if (argc != 2 + n * n) {
        std::cerr << "Incorrect number of matrix elements. Expected " << n * n << " elements." << std::endl;
        return 1;
    }

    std::vector<std::vector<double>> A = parseMatrixFromArgs(n, argv);

    std::vector<std::vector<double>> L, U;
    luDecomposition(A, L, U);

    std::cout << "Lower Triangular Matrix (L):\n";
    for (const auto& row : L) {
        for (const auto& val : row) {
            std::cout << val << " ";
        }
        std::cout << "\n";
    }

    std::cout << "Upper Triangular Matrix (U):\n";
    for (const auto& row : U) {
        for (const auto& val : row) {
            std::cout << val << " ";
        }
        std::cout << "\n";
    }

    return 0;
}

