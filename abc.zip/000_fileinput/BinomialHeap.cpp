#include <bits/stdc++.h>
using namespace std;

typedef struct Node {
    int val;
    int rank;
    struct Node* parent;
    struct Node* child;
    struct Node* next;
} Node;

// Function to create a new node
Node* createNode(int val) {
    Node* node = (Node*)malloc(sizeof(Node));
    node->val = val;
    node->rank = 0;
    node->parent = node->child = node->next = NULL;
    return node;
}

typedef struct Heap {
    Node* head;
} Heap;

// Function to combine two trees into one
Node* combineTrees(Node* a, Node* b) {
    if (a->val > b->val) {
        Node* temp = a;
        a = b;
        b = temp;
    }
    b->parent = a;
    b->next = a->child;
    a->child = b;
    a->rank++;
    return a;
}

// Function to merge two heaps
Heap* mergeHeaps(Heap* h1, Heap* h2) {
    Heap* merged = (Heap*)malloc(sizeof(Heap));
    merged->head = NULL;

    Node* prev = NULL;
    Node* cur = h1->head;
    Node* nxt = h2->head;

    while (cur || nxt) {
        Node* minNode;
        if (!nxt || (cur && cur->rank <= nxt->rank)) {
            minNode = cur;
            cur = cur->next;
        } else {
            minNode = nxt;
            nxt = nxt->next;
        }

        if (merged->head == NULL) {
            merged->head = minNode;
            prev = merged->head;
        } else {
            prev->next = minNode;
            prev = prev->next;
        }
    }

    Node* curr = merged->head;
    Node* last = NULL;
    Node* nxtNode = curr ? curr->next : NULL;

    while (nxtNode) {
        if ((curr->rank != nxtNode->rank) || 
            (nxtNode->next && nxtNode->next->rank == curr->rank)) {
            last = curr;
            curr = nxtNode;
        } else {
            if (curr->val <= nxtNode->val) {
                curr->next = nxtNode->next;
                curr = combineTrees(curr, nxtNode);
            } else {
                if (last) {
                    last->next = nxtNode;
                } else {
                    merged->head = nxtNode;
                }
                nxtNode = combineTrees(nxtNode, curr);
                curr = nxtNode;
            }
        }
        nxtNode = curr->next;
    }

    return merged;
}

// Function to add a new node to the heap
void add(Heap** heap, int val) {
    Heap* tempHeap = (Heap*)malloc(sizeof(Heap));
    tempHeap->head = createNode(val);
    *heap = mergeHeaps(*heap, tempHeap);
}

// Function to gather and print all edges from a node
void gatherEdges(Node* root) {
    Node* child = root->child;
    int isFirst = 1;

    while (child) {
        if (!isFirst) printf(",");
        printf("(%d,%d)", root->val, child->val);
        gatherEdges(child);
        child = child->next;
        isFirst = 0;
    }
}

// Function to print a tree from the heap
void printTree(Node* root) {
    printf("B%d,%d,[", root->rank, root->val);
    if (root->child) {
        gatherEdges(root);
    }
    printf("]\n");
}

// Function to print the heap
void printHeap(Heap* heap) {
    Node* root = heap->head;
    while (root) {
        printTree(root);
        root = root->next;
    }
}

// Function to get a specific token from a string
char* getToken(const char* str, const char* delim, int index) {
    char* strCopy = strdup(str);
    char* token = strtok(strCopy, delim);
    while (token && index--) token = strtok(NULL, delim);
    char* result = token ? strdup(token) : NULL;
    free(strCopy);
    return result;
}

int main() {
    // Open the file "input.txt" for reading
    ifstream file("input.txt");
    
    if (!file) {
        cerr << "Unable to open file input.txt" << endl;
        return 1;
    }

    string input;
    getline(file, input); // Read the first line from the file

    file.close();  // Close the file after reading

    // Initialize the heap
    Heap* heap = (Heap*)malloc(sizeof(Heap));
    heap->head = NULL;

    // Split the input string by commas and add each value to the heap
    const char* delim = ",";
    int index = 0;
    char* token;

    while ((token = getToken(input.c_str(), delim, index)) != NULL) {
        int val = atoi(token);
        add(&heap, val);
        free(token);
        index++;
    }

    // Print the resulting heap
    printHeap(heap);
    return 0;
}

