#include <iostream>
#include <fstream>
#include <cstring>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 1024

void receive_file(int client_socket, const std::string& save_directory) {
    char buffer[BUFFER_SIZE] = {0};
    std::string filename;

    // Receive the file name
    int bytes_read = read(client_socket, buffer, BUFFER_SIZE);
    if (bytes_read <= 0) {
        std::cerr << "Failed to receive file name.\n";
        return;
    }
    filename = std::string(buffer, bytes_read);
    std::string full_path = save_directory + "/" + filename;

    // Open file for writing
    std::ofstream outfile(full_path, std::ios::binary);
    if (!outfile) {
        std::cerr << "Failed to open file for writing: " << full_path << "\n";
        return;
    }

    std::cout << "Receiving file: " << filename << "\n";

    // Receive file content
    while ((bytes_read = read(client_socket, buffer, BUFFER_SIZE)) > 0) {
        outfile.write(buffer, bytes_read);
    }

    outfile.close();
    std::cout << "File saved to: " << full_path << "\n";
}

int main() {
    int server_fd, client_socket;
    struct sockaddr_in address;
    int addrlen = sizeof(address);

    // Create socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    // Bind the socket
    if (bind(server_fd, (struct sockaddr*)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }

    // Listen for connections
    if (listen(server_fd, 3) < 0) {
        perror("Listen failed");
        exit(EXIT_FAILURE);
    }

    std::cout << "Server is waiting for connections...\n";

    // Accept a connection
    client_socket = accept(server_fd, (struct sockaddr*)&address, (socklen_t*)&addrlen);
    if (client_socket < 0) {
        perror("Client connection failed");
        exit(EXIT_FAILURE);
    }

    std::cout << "Client connected.\n";

    // Specify the directory to save files
    std::string save_directory = "./received_files";

    // Receive file from the client
    receive_file(client_socket, save_directory);

    close(client_socket);
    close(server_fd);

    return 0;
}
