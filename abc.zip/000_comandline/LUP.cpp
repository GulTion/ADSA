/*
 * INPUT FORMAT:
 *
 * The program expects the following command-line arguments:
 * 1. <size> (required) - The size of the square matrix (n x n).
 *    Example: 3
 *
 * 2. <matrix elements row-wise> (required) - The n x n elements of the matrix, provided 
 *    as space-separated values in row-major order. The total number of elements should be 
 *    exactly n * n.
 *    Example for a 3x3 matrix:
 *    1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0
 *
 * 3. <B elements> (required) - The vector B of size n (the right-hand side of the system Ax = B),
 *    provided as n space-separated values.
 *    Example: 1.0 2.0 3.0
 *
 * The program performs LU decomposition with partial pivoting (LUP decomposition) on the matrix A
 * and solves the system of equations Ax = B, where:
 * - A is the input matrix,
 * - x is the solution vector, and
 * - B is the right-hand side vector.
 * 
 * It outputs:
 * 1. The lower triangular matrix L,
 * 2. The upper triangular matrix U,
 * 3. The permutation matrix P,
 * 4. The solution vector X.
 *
 * Example command to run the program:
 * $ ./LUPDecomposition 3 1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 1.0 2.0 3.0
 *
 * Output:
 * Lower Matrix:
 * 1 0 0 
 * 0.5 1 0 
 * 0.5 0.333333 1 
 *
 * Upper Matrix:
 * 2 3 4 
 * 0 0.5 1 
 * 0 0 0.333333 
 *
 * Permutation Matrix:
 * 0 1 0 
 * 1 0 0 
 * 0 0 1 
 *
 * Solution:
 * 1.0 2.0 3.0
 *
 * Notes:
 * - The matrix elements and the vector B are expected to be floating-point numbers.
 * - The matrix must be square (i.e., n x n).
 * - The program performs partial pivoting during LU decomposition, which may swap rows in the matrix.
 * - The program assumes that the matrix is non-singular (i.e., the LU decomposition exists).
 * - Ensure that the correct number of elements are provided. The program expects exactly n * n + n elements.
 */


#include <bits/stdc++.h>
using namespace std;

void LUPDecomposition(vector<vector<double>> &A, vector<vector<double>> &L, vector<vector<double>> &U, vector<int> &P, int n) {
    for (int i = 0; i < n; i++) {
        P[i] = i; 
    }

    for (int i = 0; i < n; i++) {
        double pivot = 0.0;
        int pivotIndex = i;

        for (int j = i; j < n; j++) {
            if (abs(A[j][i]) > abs(pivot)) {
                pivot = A[j][i];
                pivotIndex = j;
            }
        }

        if (pivot == 0) {
            throw runtime_error("Matrix is singular.");
        }

        if (pivotIndex != i) {
            swap(A[i], A[pivotIndex]);
            swap(P[i], P[pivotIndex]);
        }

        for (int j = i + 1; j < n; j++) {
            A[j][i] /= A[i][i];
            for (int k = i + 1; k < n; k++) {
                A[j][k] -= A[j][i] * A[i][k];
            }
        }
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (i > j) {
                L[i][j] = A[i][j];
                U[i][j] = 0;
            } else if (i == j) {
                L[i][j] = 1;
                U[i][j] = A[i][j]; 
            } else {
                L[i][j] = 0;
                U[i][j] = A[i][j]; 
            }
        }
    }
}

void forwardSubstitution(const vector<vector<double>> &L, const vector<int> &P, const vector<double> &B, vector<double> &Y, int n) {
    for (int i = 0; i < n; i++) {
        Y[i] = B[P[i]];
        for (int j = 0; j < i; j++) {
            Y[i] -= L[i][j] * Y[j];
        }
    }
}

void backwardSubstitution(const vector<vector<double>> &U, const vector<double> &Y, vector<double> &X, int n) {
    for (int i = n - 1; i >= 0; i--) {
        X[i] = Y[i];
        for (int j = i + 1; j < n; j++) {
            X[i] -= U[i][j] * X[j];
        }
        X[i] /= U[i][i];
    }
}

void printMatrix(const vector<vector<double>> &matrix, const string &name) {
    cout << name << " Matrix:\n";
    for (const auto &row : matrix) {
        for (const auto &val : row) {
            cout << val << " ";
        }
        cout << "\n";
    }
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        cerr << "Usage: " << argv[0] << " <size> <matrix elements row-wise> <B elements>" << endl;
        return 1;
    }

    int n = stoi(argv[1]);
    if (n <= 0) {
        cerr << "Matrix size must be positive." << endl;
        return 1;
    }
    if (argc != 2 + n * (n + 1)) {
        cerr << "Incorrect number of elements. Expected " << n * (n + 1) << " elements." << endl;
        return 1;
    }

    vector<vector<double>> A(n, vector<double>(n));
    vector<double> B(n);
    int argIndex = 2;

    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            A[i][j] = stod(argv[argIndex++]);
        }
        B[i] = stod(argv[argIndex++]);
    }

    vector<vector<double>> L(n, vector<double>(n, 0));
    vector<vector<double>> U(n, vector<double>(n, 0));
    vector<int> P(n);
    vector<double> Y(n);
    vector<double> X(n);

    try {
        LUPDecomposition(A, L, U, P, n);
        forwardSubstitution(L, P, B, Y, n);
        backwardSubstitution(U, Y, X, n);

        printMatrix(L, "Lower");
        printMatrix(U, "Upper");

        cout << "\nPermutation Matrix:\n";
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                cout << (P[i] == j ? 1 : 0) << " ";
            }
            cout << "\n";
        }

        cout << "\nSolution:\n";
        for (const auto &val : X) {
            cout << val << " ";
        }
        cout << endl;

    } catch (const runtime_error &e) {
        cout << e.what() << endl;
        return 1;
    }

    return 0;
}

