#include <iostream>
#include <vector>
#include <climits>
#include <fstream> // For file operations

using namespace std;

pair<int, vector<int> > assemblyLineScheduling(const vector<vector<int> >& a, const vector<vector<int> >& t, const vector<int>& e, const vector<int>& x) {
    int n = a[0].size(); // Number of stations
    vector<int> T1(n), T2(n); // Times to finish at each station
    vector<int> line1(n), line2(n); // Line taken at each station
    T1[0] = e[0] + a[0][0]; // Entry time for line 1
    T2[0] = e[1] + a[1][0]; // Entry time for line 2

    // Fill T1 and T2 for each station
    for (int j = 1; j < n; ++j) {
        if (T1[j - 1] + a[0][j] <= T2[j - 1] + t[1][j] + a[0][j]) {
            T1[j] = T1[j - 1] + a[0][j];
            line1[j] = 0; // Line 1 taken
        } else {
            T1[j] = T2[j - 1] + t[1][j] + a[0][j];
            line1[j] = 1; // Line 2 taken
        }

        if (T2[j - 1] + a[1][j] <= T1[j - 1] + t[0][j] + a[1][j]) {
            T2[j] = T2[j - 1] + a[1][j];
            line2[j] = 1; // Line 2 taken
        } else {
            T2[j] = T1[j - 1] + t[0][j] + a[1][j];
            line2[j] = 0; // Line 1 taken
        }
    }

    // Add exit times
    int result = min(T1[n - 1] + x[0], T2[n - 1] + x[1]);

    // Determine which line was used at the last station
    vector<int> path(n);
    if (T1[n - 1] + x[0] < T2[n - 1] + x[1]) {
        path[n - 1] = 0; // Last station from line 1
    } else {
        path[n - 1] = 1; // Last station from line 2
    }

    // Backtrack to find the path taken
    for (int j = n - 2; j >= 0; --j) {
        if (path[j + 1] == 0) {
            path[j] = line1[j + 1];
        } else {
            path[j] = line2[j + 1];
        }
    }

    return make_pair(result, path);
}

int main() {
    int n; // Number of stations
    ifstream inputFile("input.txt"); // Open the input file

    if (!inputFile) {
        cerr << "Unable to open input file." << endl;
        return 1; // Exit if the file cannot be opened
    }

    inputFile >> n;

    vector<vector<int> > a(2, vector<int>(n)); // Processing times
    vector<vector<int> > t(2, vector<int>(n)); // Transfer times
    vector<int> e(2); // Entry times
    vector<int> x(2); // Exit times

    inputFile >> e[0] >> e[1]; // Entry times
    inputFile >> x[0] >> x[1]; // Exit times

    for (int i = 0; i < n; ++i) {
        inputFile >> a[0][i]; // Processing times for line 1
    }

    for (int i = 0; i < n; ++i) {
        inputFile >> a[1][i]; // Processing times for line 2
    }

    for (int i = 1; i < n; ++i) {
        inputFile >> t[0][i]; // Transfer times from line 1 to line 2
    }

    for (int i = 1; i < n; ++i) {
        inputFile >> t[1][i]; // Transfer times from line 2 to line 1
    }

    inputFile.close(); // Close the input file

    pair<int, vector<int> > result = assemblyLineScheduling(a, t, e, x);
    cout << "Minimum time to process all tasks: " << result.first << endl;

    // Output the line taken at each station
    cout << "Line taken at each station: ";
    for (int j = 0; j < n; ++j) {
        cout << (result.second[j] + 1) << " "; // +1 to convert 0-indexed to 1-indexed
    }
    cout << endl;

    return 0;
}
