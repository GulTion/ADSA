#include <iostream>
#include <vector>
#include <climits>
#include <queue>
#include <sstream>
#include <fstream> // For file handling

using namespace std;

struct Edge {
    int v;
    int weight;
};

class Graph {
    int V; 
    vector<vector<Edge>> adj; 

public:
    Graph(int V) : V(V), adj(V) {}

    void addEdge(int u, int v, int weight) {
        adj[u].push_back({v, weight});
    }

    void dijkstra(int src) {
        vector<int> dist(V, INT_MAX);
        vector<bool> visited(V, false);
        typedef pair<int, int> pii;
        priority_queue<pii, vector<pii>, greater<pii>> pq;

        pq.push(pii(0, src));
        dist[src] = 0;

        while (!pq.empty()) {
            int u = pq.top().second;
            pq.pop();

            if (visited[u]) continue;
            visited[u] = true;

            for (size_t i = 0; i < adj[u].size(); ++i) {
                const Edge& edge = adj[u][i];
                int v = edge.v;
                int weight = edge.weight;
                if (dist[u] != INT_MAX && dist[u] + weight < dist[v]) {
                    dist[v] = dist[u] + weight;
                    pq.push(pii(dist[v], v));
                }
            }
        }

        cout << "Vertex Distance from Source" << endl;
        for (int i = 0; i < V; ++i) {
            stringstream ss;
            ss << dist[i];
            string distance = (dist[i] == INT_MAX) ? "INF" : ss.str();
            cout << i << "\t\t" << distance << endl;
        }
    }
};

int main() {
    ifstream inputFile("input.txt");
    if (!inputFile) {
        cerr << "Unable to open file input.txt" << endl;
        return 1; // Exit if the file cannot be opened
    }

    int V;
    inputFile >> V; // Read number of vertices
    Graph g(V);

    int u, v, weight;
    while (inputFile >> u >> v >> weight) {
        g.addEdge(u, v, weight); // Read edges
    }

    inputFile.close(); // Close the file

    cout << "Running Dijkstra's algorithm from source vertex " << 0 << endl;
    g.dijkstra(0);

    return 0;
}

