#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>

#define MAX_SIZE 100 // Maximum matrix size (adjustable)

void readMatrixFromFile(const char* filename, double matrix[MAX_SIZE][MAX_SIZE], int& n) {
    std::ifstream inputFile(filename);
    if (!inputFile) {
        std::cerr << "Error: Could not open the file!" << std::endl;
        exit(1);
    }
    
    std::string line;
    n = 0;
    while (getline(inputFile, line) && n < MAX_SIZE) {
        std::stringstream ss(line);
        std::string value;
        int col = 0;
        while (getline(ss, value, ',') && col < MAX_SIZE) {
            matrix[n][col] = std::stod(value);
            col++;
        }
        n++;
    }
    inputFile.close();
}

void luDecomposition(double matrix[MAX_SIZE][MAX_SIZE], double L[MAX_SIZE][MAX_SIZE], double U[MAX_SIZE][MAX_SIZE], int n) {
    for (int i = 0; i < n; i++) {
        // Initialize U's row
        for (int k = i; k < n; k++) {
            double sum = 0;
            for (int j = 0; j < i; j++) {
                sum += L[i][j] * U[j][k];
            }
            U[i][k] = matrix[i][k] - sum;
        }

        // Initialize L's column
        for (int k = i; k < n; k++) {
            if (i == k) {
                L[i][i] = 1; // Diagonal as 1 for L
            } else {
                double sum = 0;
                for (int j = 0; j < i; j++) {
                    sum += L[k][j] * U[j][i];
                }
                L[k][i] = (matrix[k][i] - sum) / U[i][i];
            }
        }
    }
}

void printMatrix(double matrix[MAX_SIZE][MAX_SIZE], int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            std::cout << std::setw(10) << matrix[i][j] << " ";
        }
        std::cout << std::endl;
    }
}

int main() {
    double matrix[MAX_SIZE][MAX_SIZE] = {0};
    double L[MAX_SIZE][MAX_SIZE] = {0};
    double U[MAX_SIZE][MAX_SIZE] = {0};
    int n = 0;

    // Read matrix from input.txt
    readMatrixFromFile("input.txt", matrix, n);

    // Perform LU Decomposition
    luDecomposition(matrix, L, U, n);

    // Output L and U matrices
    std::cout << "L matrix:" << std::endl;
    printMatrix(L, n);

    std::cout << "\nU matrix:" << std::endl;
    printMatrix(U, n);

    return 0;
}
