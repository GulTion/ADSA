/*
 * INPUT FORMAT:
 *
 * The program expects the following command-line arguments:
 * 1. <dimension1> <dimension2> ... <dimensionN> (required) - A sequence of integers representing the dimensions 
 *    of matrices in a matrix chain multiplication problem. The dimensions should be provided as a space-separated list.
 *    Each matrix is represented by two integers: rows and columns, and the list should contain N+1 dimensions for N matrices.
 *    Example:
 *    For a chain of matrices A1 (10x20), A2 (20x30), and A3 (30x40), the input dimensions would be:
 *    10 20 30 40
 *
 * The program will calculate the minimum number of scalar multiplications required to multiply the chain of matrices 
 * using dynamic programming.
 * 
 * Example command to run the program:
 * $ ./matrixChainMultiplication 10 20 30 40
 *
 * Output:
 * Minimum number of scalar multiplications: 18000
 *
 * Explanation:
 * - For the matrices with dimensions 10x20, 20x30, and 30x40, the optimal parenthesization gives a minimum cost of 18000 scalar multiplications.
 * 
 * Notes:
 * - The number of matrices is one less than the number of dimensions. For example, 4 dimensions represent 3 matrices.
 * - The input must have at least 2 dimensions (representing one matrix), and no more than the required number of dimensions (N+1 for N matrices).
 * - The program assumes that matrix multiplication is possible (i.e., the dimensions are compatible for multiplication).
 */


#include <iostream>
#include <climits>
#include <sstream>
#include <vector>
#include <cstdlib>  // For std::stoi

using namespace std;

// Function to compute matrix chain order
void matrixChainOrder(int* dims, int n, int** m, int** s) {
    for (int i = 1; i < n; i++)
        m[i][i] = 0; // No cost to multiply one matrix
    
    // Loop through all possible chain lengths
    for (int L = 2; L < n; L++) { // L is chain length
        for (int i = 1; i <= n - L; i++) {
            int j = i + L - 1;
            m[i][j] = INT_MAX;
            for (int k = i; k < j; k++) {
                int q = m[i][k] + m[k + 1][j] + dims[i - 1] * dims[k] * dims[j];
                if (q < m[i][j]) {
                    m[i][j] = q;
                    s[i][j] = k; // Record the split point
                }
            }
        }
    }
}

// Function to print optimal parenthesization
void printOptimalParens(int** s, int i, int j) {
    if (i == j) {
        cout << "A" << i;
    } else {
        cout << "(";
        printOptimalParens(s, i, s[i][j]);
        printOptimalParens(s, s[i][j] + 1, j);
        cout << ")";
    }
}

// Function to print m and s tables with proper labels
void printTable(int** table, int n, const string& name, bool isSplitTable = false) {
    cout << name << " Table:" << endl;
    for (int i = 1; i < n; i++) {
        for (int j = 1; j < n; j++) {
            if (i <= j) {
                if (isSplitTable && i == j) {
                    cout << "-\t"; // Print '-' in diagonal for s table
                } else {
                    cout << table[i][j] << "\t";
                }
            } else {
                cout << "-\t"; // Print '-' for unused cells
            }
        }
        cout << endl;
    }
    cout << endl;
}

int main(int argc, char* argv[]) {
    // Check if enough arguments are passed
    if (argc < 3) {
        cout << "Usage: " << argv[0] << " <dimension1> <dimension2> ... <dimensionN>" << endl;
        cout << "You must provide at least two dimensions for matrix multiplication." << endl;
        return 1;
    }

    // Parse matrix dimensions from command-line arguments
    vector<int> dims;
    for (int i = 1; i < argc; i++) {
        dims.push_back(stoi(argv[i]));  // Convert string to integer and store it in dims vector
    }

    int n = dims.size();  // n is the number of matrices, which is dimensions.size() - 1

    // Convert dims vector to a raw array for matrix chain computation
    int* dimsArray = new int[n];
    for (int i = 0; i < n; i++) {
        dimsArray[i] = dims[i];
    }

    // Define m and s tables dynamically
    int** m = new int*[n];
    int** s = new int*[n];
    for (int i = 0; i < n; i++) {
        m[i] = new int[n];
        s[i] = new int[n];
    }

    // Compute matrix chain order
    matrixChainOrder(dimsArray, n, m, s);

    // Output the minimum cost
    cout << "Minimum number of multiplications is: " << m[1][n - 1] << endl;

    // Output the m and s tables
    printTable(m, n, "m");
    printTable(s, n, "s", true); // true flag to mark s as split table

    // Output the optimal parenthesization
    cout << "Optimal parenthesization: ";
    printOptimalParens(s, 1, n - 1);
    cout << endl;

    // Deallocate dynamically allocated memory
    for (int i = 0; i < n; i++) {
        delete[] m[i];
        delete[] s[i];
    }
    delete[] m;
    delete[] s;
    delete[] dimsArray;

    return 0;
}

