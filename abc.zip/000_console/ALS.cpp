#include <stdio.h>
#include <stdlib.h>

#define MIN(a, b) ((a) < (b) ? (a) : (b))

typedef struct {
    int minTime;
    int* path;
} Result;

Result assemblyLineScheduling(int** a, int** t, int* e, int* x, int n) {
    int* T1 = (int*)malloc(n * sizeof(int));
    int* T2 = (int*)malloc(n * sizeof(int));
    int* line1 = (int*)malloc(n * sizeof(int));
    int* line2 = (int*)malloc(n * sizeof(int));
    int* path = (int*)malloc(n * sizeof(int));
    Result result;

    T1[0] = e[0] + a[0][0];
    T2[0] = e[1] + a[1][0];

    for (int j = 1; j < n; ++j) {
        if (T1[j - 1] + a[0][j] <= T2[j - 1] + t[1][j] + a[0][j]) {
            T1[j] = T1[j - 1] + a[0][j];
            line1[j] = 0;
        } else {
            T1[j] = T2[j - 1] + t[1][j] + a[0][j];
            line1[j] = 1;
        }

        if (T2[j - 1] + a[1][j] <= T1[j - 1] + t[0][j] + a[1][j]) {
            T2[j] = T2[j - 1] + a[1][j];
            line2[j] = 1;
        } else {
            T2[j] = T1[j - 1] + t[0][j] + a[1][j];
            line2[j] = 0;
        }
    }

    result.minTime = MIN(T1[n - 1] + x[0], T2[n - 1] + x[1]);

    if (T1[n - 1] + x[0] < T2[n - 1] + x[1]) {
        path[n - 1] = 0;
    } else {
        path[n - 1] = 1;
    }

    for (int j = n - 2; j >= 0; --j) {
        if (path[j + 1] == 0) {
            path[j] = line1[j + 1];
        } else {
            path[j] = line2[j + 1];
        }
    }

    result.path = path;

    free(T1);
    free(T2);
    free(line1);
    free(line2);

    return result;
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        printf("Usage: %s <number of stations> <entry times> <exit times> <processing times> <transfer times>\n", argv[0]);
        return 1;
    }

    int n = atoi(argv[1]);

    int* a[2];
    int* t[2];
    int e[2];
    int x[2];

    a[0] = (int*)malloc(n * sizeof(int));
    a[1] = (int*)malloc(n * sizeof(int));
    t[0] = (int*)malloc(n * sizeof(int));
    t[1] = (int*)malloc(n * sizeof(int));

    e[0] = atoi(argv[2]);
    e[1] = atoi(argv[3]);
    x[0] = atoi(argv[4]);
    x[1] = atoi(argv[5]);

    for (int i = 0; i < n; ++i) {
        a[0][i] = atoi(argv[6 + i]);
        a[1][i] = atoi(argv[6 + n + i]);
    }

    for (int i = 0; i < n - 1; ++i) {
        t[0][i + 1] = atoi(argv[6 + 2 * n + i]);
        t[1][i + 1] = atoi(argv[6 + 3 * n + i]);
    }

    Result result = assemblyLineScheduling(a, t, e, x, n);

    printf("Minimum time to process all tasks: %d\n", result.minTime);
    printf("Line taken at each station: ");
    for (int j = 0; j < n; ++j) {
        printf("%d ", result.path[j] + 1);
    }
    printf("\n");

    free(a[0]);
    free(a[1]);
    free(a);
    free(t[0]);
    free(t[1]);
    free(t);
    free(result.path);

    return 0;
}
