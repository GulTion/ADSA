/*
INPUT:
- <V>: Number of vertices in the graph (must be a positive integer).
- <E>: Number of edges in the graph (must be a non-negative integer).
- <u1> <v1> <weight1>: The first edge, with u1 as the starting vertex, v1 as the destination vertex, and weight1 as the edge's weight.
- <u2> <v2> <weight2>: The second edge, with u2 as the starting vertex, v2 as the destination vertex, and weight2 as the edge's weight.
- ...
- <uE> <vE> <weightE>: The E-th edge, with uE as the starting vertex, vE as the destination vertex, and weightE as the edge's weight.
- <src>: The source vertex for running Dijkstra's algorithm.

The input should be provided in the following format:
- First argument: number of vertices (V)
- Second argument: number of edges (E)
- Then, for each edge, the triplet <u, v, weight> (for E edges in total)
- The last argument: source vertex (src)

Example Input:
./dijkstra.exe 5 6 0 1 10 0 2 5 1 2 2 1 3 1 2 4 3 3 4 5 0
This represents:
- A graph with 5 vertices and 6 edges.
- Edges:
  0 -> 1 (weight 10)
  0 -> 2 (weight 5)
  1 -> 2 (weight 2)
  1 -> 3 (weight 1)
  2 -> 4 (weight 3)
  3 -> 4 (weight 5)
- The source vertex is 0.
*/


#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
#include<stdbool.h>
#define MAX_VERTICES 100

typedef struct {
    int v;
    int weight;
} edge;

typedef struct {
    int count;
    edge edges[MAX_VERTICES][MAX_VERTICES];
} graph;

void initgraph(graph *g, int V) {
    g->count = V;
    for (int i = 0; i < V; i++) {
        for (int j = 0; j < V; j++) {
            g->edges[i][j].v = -1;
            g->edges[i][j].weight = INT_MAX;
        }
    }
}

void addedge(graph *g, int u, int v, int weight) {
    g->edges[u][v].v = v;
    g->edges[u][v].weight = weight;
}

int mindistance(int dist[], bool visited[], int V) {
    int min = INT_MAX;
    int minindex = -1;
    for (int i = 0; i < V; i++) {
        if (!visited[i] && dist[i] <= min) {
            min = dist[i];
            minindex = i;
        }
    }
    return minindex;
}

void dijkstra(graph *g, int src) {
    int n;
    n = g->count;
    int dist[MAX_VERTICES];
    bool visited[MAX_VERTICES];
    
    for (int i = 0; i < n; i++) {
        dist[i] = INT_MAX;
        visited[i] = false;
    }

    dist[src] = 0;
    for (int i = 0; i < n - 1; i++) {
        int u = mindistance(dist, visited, n);
        visited[u] = true;

        for (int j = 0; j < n; j++) {
            if (!visited[j] && g->edges[u][j].weight != INT_MAX && dist[u] != INT_MAX && dist[u] + g->edges[u][j].weight < dist[j]) {
                dist[j] = dist[u] + g->edges[u][j].weight;
            }
        }
    }

    printf("Vertex and distance from source vertex\n");
    for (int i = 0; i < n; i++) {
        if (dist[i] == INT_MAX) {
            printf("%d INF\n", i);
        } else {
            printf("%d %d\n", i, dist[i]);
        }
    }
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        printf("Usage: %s <V> <E> <u1> <v1> <weight1> ... <uE> <vE> <weightE> <src>\n", argv[0]);
        return 1;
    }

    int V = atoi(argv[1]);
    int E = atoi(argv[2]);

    if (V <= 0 || E < 0) {
        printf("Invalid number of vertices or edges.\n");
        return 1;
    }

    graph g;
    initgraph(&g, V);

    int argIndex = 3;
    for (int i = 0; i < E; i++) {
        if (argIndex + 2 >= argc) {
            printf("Insufficient number of arguments for edges.\n");
            return 1;
        }
       
        int u = atoi(argv[argIndex]);
        int v = atoi(argv[argIndex + 1]);
        int weight = atoi(argv[argIndex + 2]);
       
        if (u < 0 || u >= V || v < 0 || v >= V) {
            printf("Invalid edge vertices. They must be between 0 and %d.\n", V - 1);
            return 1;
        }

        addedge(&g, u, v, weight);
        argIndex += 3;
    }

    int src = atoi(argv[argIndex]);

    if (src < 0 || src >= V) {
        printf("Invalid source vertex. It must be between 0 and %d.\n", V - 1);
        return 1;
    }

    printf("Dijkstra running from source vertex: %d\n", src);
    dijkstra(&g, src);

    return 0;
}
