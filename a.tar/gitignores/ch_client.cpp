#include <iostream>
#include <thread>
#include <cstring>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 1024

void receive_messages(int socket) {
    char buffer[BUFFER_SIZE];
    while (true) {
        memset(buffer, 0, BUFFER_SIZE);

        // Receive messages from server
        int bytes_received = recv(socket, buffer, BUFFER_SIZE, 0);
        if (bytes_received <= 0) {
            std::cerr << "Disconnected from server.\n";
            close(socket);
            exit(EXIT_FAILURE);
        }

        // Print received message
        std::cout << buffer << std::endl;
    }
}

void send_messages(int socket) {
    std::string message;
    while (true) {
        std::getline(std::cin, message);

        // Send message to server
        send(socket, message.c_str(), message.size(), 0);
    }
}

int main() {
    int client_socket;
    struct sockaddr_in serv_addr;

    // Create socket
    if ((client_socket = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        std::cerr << "Socket creation error\n";
        return -1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);

    // Convert IPv4 address from text to binary
    if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) {
        std::cerr << "Invalid address/Address not supported\n";
        return -1;
    }

    // Connect to the server
    if (connect(client_socket, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        std::cerr << "Connection failed\n";
        return -1;
    }

    std::cout << "Connected to the server.\n";

    // Start threads for sending and receiving messages
    std::thread receiver(receive_messages, client_socket);
    std::thread sender(send_messages, client_socket);

    // Wait for both threads to finish
    receiver.join();
    sender.join();

    close(client_socket);
    return 0;
}
