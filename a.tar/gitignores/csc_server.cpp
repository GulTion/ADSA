#include <iostream>
#include <cstring>
#include <unistd.h>
#include <arpa/inet.h>
#include <signal.h>

#define PORT 8080

bool running = true;

void handle_sigint(int) {
    running = false;
}

int main() {
    int server_fd, client1_socket, client2_socket;
    struct sockaddr_in address;
    int addrlen = sizeof(address);
    char buffer[1024] = {0};

    // Handle Ctrl+C
    signal(SIGINT, handle_sigint);

    // Create socket file descriptor
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    // Attach socket to the port
    int opt = 1;
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt))) {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    if (bind(server_fd, (struct sockaddr*)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }

    if (listen(server_fd, 2) < 0) {
        perror("Listen");
        exit(EXIT_FAILURE);
    }

    std::cout << "Server is waiting for connections...\n";

    client1_socket = accept(server_fd, (struct sockaddr*)&address, (socklen_t*)&addrlen);
    if (client1_socket < 0) {
        perror("Client1 accept failed");
        exit(EXIT_FAILURE);
    }
    std::cout << "Client1 connected.\n";

    client2_socket = accept(server_fd, (struct sockaddr*)&address, (socklen_t*)&addrlen);
    if (client2_socket < 0) {
        perror("Client2 accept failed");
        exit(EXIT_FAILURE);
    }
    std::cout << "Client2 connected.\n";

    while (running) {
        memset(buffer, 0, sizeof(buffer));

        // Receive data from Client1
        int valread = read(client1_socket, buffer, 1024);
        if (valread <= 0) break;

        char received_char = buffer[0];
        char modified_char = received_char - 1;

        // Send modified data to Client2
        send(client2_socket, &modified_char, sizeof(modified_char), 0);

        std::cout << "Server received: " << received_char << ", sent: " << modified_char << std::endl;
    }

    close(client1_socket);
    close(client2_socket);
    close(server_fd);
    std::cout << "Server terminated.\n";
    return 0;
}
