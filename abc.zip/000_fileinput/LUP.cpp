#include <iostream>
#include <fstream>
#include <cmath>
#include <cstring>

using namespace std;

const int MAX = 100;
double A[MAX][MAX], L[MAX][MAX], U[MAX][MAX], P[MAX][MAX], B[MAX], X[MAX], Y[MAX];
int n;

// Function to perform LUP decomposition
void LUP_Decomposition() {
    for (int i = 0; i < n; i++) {
        P[i][i] = 1;
    }
    
    for (int k = 0; k < n; k++) {
        double max = 0.0;
        int k_prime = k;
        
        for (int i = k; i < n; i++) {
            if (fabs(A[i][k]) > max) {
                max = fabs(A[i][k]);
                k_prime = i;
            }
        }

        if (max == 0) {
            cout << "Matrix is singular" << endl;
            return;
        }

        // Swap rows k and k'
        for (int i = 0; i < n; i++) {
            double temp = A[k][i];
            A[k][i] = A[k_prime][i];
            A[k_prime][i] = temp;
            
            temp = P[k][i];
            P[k][i] = P[k_prime][i];
            P[k_prime][i] = temp;
        }

        double temp = B[k];
        B[k] = B[k_prime];
        B[k_prime] = temp;

        for (int i = k + 1; i < n; i++) {
            A[i][k] /= A[k][k];
            for (int j = k + 1; j < n; j++) {
                A[i][j] -= A[i][k] * A[k][j];
            }
        }
    }
    
    // Separate L and U from modified A
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (i > j) {
                L[i][j] = A[i][j];
                U[i][j] = 0;
            } else if (i == j) {
                L[i][j] = 1;
                U[i][j] = A[i][j];
            } else {
                L[i][j] = 0;
                U[i][j] = A[i][j];
            }
        }
    }
}

// Forward substitution to solve Ly = Pb
void forwardSubstitution() {
    for (int i = 0; i < n; i++) {
        Y[i] = B[i];
        for (int j = 0; j < i; j++) {
            Y[i] -= L[i][j] * Y[j];
        }
    }
}

// Backward substitution to solve Ux = y
void backwardSubstitution() {
    for (int i = n - 1; i >= 0; i--) {
        X[i] = Y[i];
        for (int j = i + 1; j < n; j++) {
            X[i] -= U[i][j] * X[j];
        }
        X[i] /= U[i][i];
    }
}

void printMatrix(double matrix[MAX][MAX], int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            cout << matrix[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {
    ifstream infile("input.txt");
    if (!infile) {
        cout << "Error opening file!" << endl;
        return 1;
    }

    // Determine the size of the augmented matrix
    n = 0;
    char line[MAX * 10]; // Buffer for each line

    while (infile.getline(line, sizeof(line))) {
        int count = 1;
        for (int i = 0; line[i] != '\0'; i++) {
            if (line[i] == ',') {
                count++;
            }
        }

        if (n == 0) {
            n = count - 1; // Total columns - 1 for augmented column
        }
    }

    infile.clear();
    infile.seekg(0, ios::beg); // Reset file pointer to the beginning

    // Read augmented matrix from the file
    for (int i = 0; i < n; i++) {
        for (int j = 0; j <= n; j++) {
            if (j == n) {
                infile >> B[i]; // Read the last column as B
            } else {
                infile >> A[i][j];
            }
            if (j < n) {
                infile.ignore(); // Ignore comma between numbers
            }
        }
    }

    LUP_Decomposition();
    forwardSubstitution();
    backwardSubstitution();

    cout << "L matrix:" << endl;
    printMatrix(L, n, n);

    cout << "U matrix:" << endl;
    printMatrix(U, n, n);

    cout << "P matrix:" << endl;
    printMatrix(P, n, n);

    cout << "Solutions:" << endl;
    for (int i = 0; i < n; i++) {
        cout << "X" << i + 1 << " = " << X[i] << endl;
    }

    infile.close();
    return 0;
}
