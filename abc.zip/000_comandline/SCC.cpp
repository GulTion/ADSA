/*
 * The program expects the following command-line arguments:
 * 
 * 1. <num_vertices> (required) - The number of vertices in the graph.
 *    Example: 5
 *
 * 2. <edge_from> <edge_to> (required) - A list of edges represented by pairs of integers 
 *    that indicate the directed edge from vertex <edge_from> to vertex <edge_to>.
 *    Multiple pairs of edges can be provided.
 *    Example: 0 1 1 2 2 0
 *
 *    In this case, the graph will have 5 vertices, and the edges will be:
 *    0 -> 1
 *    1 -> 2
 *    2 -> 0
 *
 * The program will then find and print all Strongly Connected Components (SCCs) in the graph.
 * 
 * Example command to run the program:
 * $ ./stronglyConnectedComponents 5 0 1 1 2 2 0
 *
 * Expected Output:
 * Strongly Connected Components in the given graph:
 * SCC: 2 1 0
*/

#include <iostream>
#include <vector>
#include <stack>
#include <algorithm>
#include <cstdlib>  // For std::stoi

using namespace std;

class Graph {
public:
    int V; // Number of vertices
    vector<vector<int>> adj; // Adjacency list

    Graph(int V) {
        this->V = V;
        adj.resize(V);
    }

    void addEdge(int v, int w) {
        adj[v].push_back(w);
    }

    void SCCUtil(int u, vector<int>& disc, vector<int>& low, stack<int>& st, vector<bool>& stackMember);
    void SCC();
};

void Graph::SCCUtil(int u, vector<int>& disc, vector<int>& low, stack<int>& st, vector<bool>& stackMember) {
    static int time = 0;

    disc[u] = low[u] = ++time;
    st.push(u);
    stackMember[u] = true;

    for (int v : adj[u]) {
        if (disc[v] == -1) {
            SCCUtil(v, disc, low, st, stackMember);
            low[u] = min(low[u], low[v]);
        } else if (stackMember[v]) {
            low[u] = min(low[u], disc[v]);
        }
    }

    int w = 0; // To store stack extracted vertices
    if (low[u] == disc[u]) {
        cout << "SCC: ";
        while (st.top() != u) {
            w = st.top();
            cout << w << " ";
            stackMember[w] = false;
            st.pop();
        }
        w = st.top();
        cout << w << " ";
        stackMember[w] = false;
        st.pop();
        cout << endl;
    }
}

void Graph::SCC() {
    vector<int> disc(V, -1);
    vector<int> low(V, -1);
    vector<bool> stackMember(V, false);
    stack<int> st;

    for (int i = 0; i < V; i++) {
        if (disc[i] == -1) {
            SCCUtil(i, disc, low, st, stackMember);
        }
    }
}

int main(int argc, char* argv[]) {
    // Check if enough arguments are passed
    if (argc < 3) {
        cout << "Usage: " << argv[0] << " <num_vertices> <edge1_from> <edge1_to> ... <edgeN_from> <edgeN_to>" << endl;
        cout << "You must provide at least one edge." << endl;
        return 1;
    }

    // Parse the number of vertices
    int V = stoi(argv[1]);  // Number of vertices (first argument)
    Graph g(V);

    // Read the edges from command-line arguments
    for (int i = 2; i < argc; i += 2) {
        int v = stoi(argv[i]);
        int w = stoi(argv[i + 1]);
        g.addEdge(v, w); // Add edge from v to w
    }

    // Output the Strongly Connected Components
    cout << "Strongly Connected Components in the given graph:\n";
    g.SCC();

    return 0;
}

