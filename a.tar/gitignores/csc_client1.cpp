#include <iostream>
#include <cstring>
#include <unistd.h>
#include <arpa/inet.h>
#include <signal.h>

#define PORT 8080

bool running = true;

void handle_sigint(int) {
    running = false;
}

int main() {
    int sock = 0;
    struct sockaddr_in serv_addr;
    char character;

    // Handle Ctrl+C
    signal(SIGINT, handle_sigint);

    // Create socket
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        std::cerr << "Socket creation error\n";
        return -1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);

    if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) {
        std::cerr << "Invalid address/Address not supported\n";
        return -1;
    }

    if (connect(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        std::cerr << "Connection failed\n";
        return -1;
    }

    std::cout << "Connected to the server. Enter characters to send ('Ctrl+C' to exit).\n";

    while (running) {
        std::cout << "Enter a character: ";
        std::cin >> character;
        send(sock, &character, sizeof(character), 0);
    }

    close(sock);
    std::cout << "Client1 terminated.\n";
    return 0;
}
