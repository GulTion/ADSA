#include <iostream>
#include <string>
#include <thread>
#include <vector>
#include <mutex>
#include <algorithm> // For std::remove
#include <cstring>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 1024

std::vector<int> clients;  // List of connected client sockets
std::mutex clients_mutex;  // Mutex for thread-safe access to clients

void broadcast_message(const std::string& message, int sender_socket) {
    std::lock_guard<std::mutex> lock(clients_mutex);
    for (int client_socket : clients) {
        if (client_socket != sender_socket) {  // Don't send message back to sender
            send(client_socket, message.c_str(), message.size(), 0);
        }
    }
}

void handle_client(int client_socket) {
    char buffer[BUFFER_SIZE];
    while (true) {
        memset(buffer, 0, BUFFER_SIZE);

        // Receive message from client
        int bytes_received = recv(client_socket, buffer, BUFFER_SIZE, 0);
        if (bytes_received <= 0) {
            std::cerr << "Client disconnected.\n";
            close(client_socket);

            // Remove client from the list
            std::lock_guard<std::mutex> lock(clients_mutex);
            clients.erase(std::remove(clients.begin(), clients.end(), client_socket), clients.end());
            break;
        }

        std::string message = "Client " + std::to_string(client_socket) + ": " + std::string(buffer);
        std::cout << message << std::endl;

        // Broadcast the message to all other clients
        broadcast_message(message, client_socket);
    }
}

int main() {
    int server_socket;
    struct sockaddr_in address;
    int addrlen = sizeof(address);

    // Create socket
    if ((server_socket = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    // Bind socket
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    if (bind(server_socket, (struct sockaddr*)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }

    // Listen for incoming connections
    if (listen(server_socket, 10) < 0) {
        perror("Listen failed");
        exit(EXIT_FAILURE);
    }

    std::cout << "Server is listening on port " << PORT << "...\n";

    while (true) {
        int client_socket = accept(server_socket, (struct sockaddr*)&address, (socklen_t*)&addrlen);
        if (client_socket < 0) {
            perror("Accept failed");
            continue;
        }

        std::cout << "New client connected: " << client_socket << "\n";

        // Add client to the list
        {
            std::lock_guard<std::mutex> lock(clients_mutex);
            clients.push_back(client_socket);
        }

        // Create a thread to handle the client
        std::thread(handle_client, client_socket).detach();
    }

    close(server_socket);
    return 0;
}
