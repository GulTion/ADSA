#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include <thread>
#include <algorithm>
#include <mutex>
#include <unordered_map>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 1024

std::mutex cout_mutex;

void process_client(int client_socket) {
    char buffer[BUFFER_SIZE];
    while (true) {
        memset(buffer, 0, BUFFER_SIZE);

        // Receive message from the client
        int bytes_received = recv(client_socket, buffer, BUFFER_SIZE, 0);
        if (bytes_received <= 0) {
            std::cout << "Client disconnected.\n";
            close(client_socket);
            break;
        }

        std::string client_message(buffer);
        std::string response;

        // Define intents and responses
        if (client_message.find("hello") != std::string::npos || 
            client_message.find("hi") != std::string::npos || 
            client_message.find("hey") != std::string::npos) {
            response = "Hi there! How can I assist you today?";
        } else if (client_message.find("laptop") != std::string::npos) {
            response = "Our latest laptop comes with a high-performance processor, a sleek design, and a long-lasting battery.";
        } else if (client_message.find("business hours") != std::string::npos) {
            response = "Our business hours are Monday to Friday, 9:00 AM to 5:00 PM.";
        } else if (client_message.find("return policy") != std::string::npos) {
            response = "Our return policy allows for returns within 30 days of purchase. Please visit our website for more details.";
        } else if (client_message.find("great") != std::string::npos || 
                   client_message.find("awesome") != std::string::npos) {
            response = "Thank you for your kind words! We're here to help. Is there anything specific you'd like assistance with?";
        } else {
            response = "I'm sorry, I didn't understand. Could you please provide more details or ask a specific question?";
        }

        // Send response to the client
        send(client_socket, response.c_str(), response.size(), 0);

        // Log the interaction
        {
            std::lock_guard<std::mutex> lock(cout_mutex);
            std::cout << "Client: " << client_message << "\n";
            std::cout << "Server: " << response << "\n";
        }
    }
}

int main() {
    int server_socket, client_socket;
    struct sockaddr_in address;
    int addrlen = sizeof(address);

    // Create socket
    if ((server_socket = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    // Bind socket
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    if (bind(server_socket, (struct sockaddr*)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }

    // Listen for incoming connections
    if (listen(server_socket, 5) < 0) {
        perror("Listen failed");
        exit(EXIT_FAILURE);
    }

    std::cout << "Chatbot server is running on port " << PORT << "...\n";

    while (true) {
        if ((client_socket = accept(server_socket, (struct sockaddr*)&address, (socklen_t*)&addrlen)) < 0) {
            perror("Accept failed");
            continue;
        }

        std::cout << "New client connected.\n";

        // Handle each client in a separate thread
        std::thread(process_client, client_socket).detach();
    }

    close(server_socket);
    return 0;
}

// g++ chatbot_server.cpp -o server -pthread
// g++ chatbot_client.cpp -o client -pthread

