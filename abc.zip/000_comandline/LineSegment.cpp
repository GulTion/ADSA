/*
 * INPUT FORMAT:
 *
 * The program expects the following command-line arguments:
 * 1. <number_of_segments> (required) - The number of line segments.
 *    Example: 3
 *
 * 2. <x1 y1 x2 y2> for each segment (required) - Four space-separated values for each line segment:
 *    - x1, y1: Coordinates of the first point of the segment.
 *    - x2, y2: Coordinates of the second point of the segment.
 *    Example: 
 *    For 3 segments, input should be:
 *    3 0 0 1 1 1 1 2 2 2 0 3 3
 *
 * The program will read the coordinates for each segment and check if any of the segments intersect. 
 * If any segments intersect, it will output the indices of the intersecting segments.
 * 
 * Example command to run the program:
 * $ ./segmentIntersection 3 0 0 1 1 1 1 2 2 2 0 3 3
 *
 * Output (if intersections exist):
 * Segments 1 and 2 intersect.
 * 
 * Output (if no intersections are found):
 * No intersecting line segments found.
 *
 * Note:
 * - The program assumes that the number of arguments and the format of the coordinates are correct.
 * - The coordinates are floating-point numbers.
 * - The program uses a geometric algorithm to check for segment intersections.
 */


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define EPSILON 1e-9

typedef struct {
    double x, y;
} Point;

typedef struct {
    Point p1, p2;
} LineSegment;

int nearlyEqual(double a, double b) {
    return fabs(a - b) < EPSILON;
}

int orientation(Point p, Point q, Point r) {
    double val = (q.y - p.y) * (r.x - q.x) - (q.x - p.x) * (r.y - q.y);
    if (nearlyEqual(val, 0)) return 0;
    return (val > 0) ? 1 : 2;
}

int onSegment(Point p, Point q, Point r) {
    return (q.x <= fmax(p.x, r.x) && q.x >= fmin(p.x, r.x) &&
            q.y <= fmax(p.y, r.y) && q.y >= fmin(p.y, r.y));
}

int doIntersect(LineSegment l1, LineSegment l2) {
    Point p1 = l1.p1, q1 = l1.p2;
    Point p2 = l2.p1, q2 = l2.p2;

    int o1 = orientation(p1, q1, p2);
    int o2 = orientation(p1, q1, q2);
    int o3 = orientation(p2, q2, p1);
    int o4 = orientation(p2, q2, q1);

    if (o1 != o2 && o3 != o4)
        return 1;

    if (o1 == 0 && onSegment(p1, p2, q1)) return 1;
    if (o2 == 0 && onSegment(p1, q2, q1)) return 1;
    if (o3 == 0 && onSegment(p2, p1, q2)) return 1;
    if (o4 == 0 && onSegment(p2, q1, q2)) return 1;

    return 0;
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: %s <number_of_segments> <x1 y1 x2 y2> ...\n", argv[0]);
        return 1;
    }

    int n = atoi(argv[1]);
    if (n <= 0 || (argc - 2) != n * 4) {
        printf("Invalid input. Please provide the correct number of coordinates for the segments.\n");
        return 1;
    }

    LineSegment segments[n];

    int idx = 2;
    for (int i = 0; i < n; i++) {
        segments[i].p1.x = atof(argv[idx++]);
        segments[i].p1.y = atof(argv[idx++]);
        segments[i].p2.x = atof(argv[idx++]);
        segments[i].p2.y = atof(argv[idx++]);
    }

    int hasIntersection = 0;
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (doIntersect(segments[i], segments[j])) {
                printf("Segments %d and %d intersect.\n", i + 1, j + 1);
                hasIntersection = 1;
            }
        }
    }
    
    if (!hasIntersection) {
        printf("No intersecting line segments found.\n");
    }

    return 0;
}
